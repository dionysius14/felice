<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<footer class="footer">
    <div class="container">
        <center>
            <p class="muted credit">Developed by <a href="http://www.nusantaratechno.com" target="_blank">NusantaraTechno.com</a></p>
        </center>
    </div>
</footer>