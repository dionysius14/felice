		
	</div>
		
	<footer>
 
		<center>
		<!--p  style="font-size:13px; padding-top:5px; font-family:arial;">Developed by NusantaraTechno.com 

		</p-->
	</center>	
	</footer>